import addresses from 'config/constants/contracts'

const chainId = process.env.REACT_APP_CHAIN_ID

export const getCakeAddress = () => {
  return addresses.cake[chainId]
}
export const getMasterChefAddress = () => {
  return addresses.masterChef[chainId]
}
export const getSousMasterChefAddress = () => {
  return addresses.sousMasterChef[chainId]
}
export const getMulticallAddress = () => {
  return addresses.mulltiCall[chainId]
}
export const getWbnbAddress = () => {
  return addresses.wbnb[chainId]
}
export const getLotteryAddress = () => {
  return addresses.lottery[chainId]
}
export const getLotteryTicketAddress = () => {
  return addresses.lotteryNFT[chainId]
}


export const getReferralAddress = () => {
  return addresses.referral[chainId]
}

export const getBUSDAddress = () => {
  return addresses.busd[chainId]
}

export const getPresaleAddress = () => {
  return addresses.presale[chainId]
}